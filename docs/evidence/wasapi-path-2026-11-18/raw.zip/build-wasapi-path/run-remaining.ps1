$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$exe=(Resolve-Path 'build-windows-validation/OFF-Release/hail_wasapi_loopback.exe').Path
$out=(Resolve-Path 'build-wasapi-path').Path
$fixture=Get-Content "$out/low-grid-manifest.json" -Raw | ConvertFrom-Json
$results=[System.Collections.Generic.List[object]]::new()
foreach($trial in @(@{name='low-grid-s16-primed';pcm='s16';seconds=5;unprimed=$false},@{name='low-grid-s16-unprimed';pcm='s16';seconds=5;unprimed=$true},@{name='low-grid-f32-sustained';pcm='f32';seconds=600;unprimed=$false})) {
    if($trial.seconds -eq 600) {
        foreach($file in 'low-grid-f32-boundary-fixed.log','low-grid-f32-unprimed.log') {
            if(!(Select-String -Path "$out/$file" -Pattern '^PASS allocations=2 frees=2 ledger_bytes=0$' -Quiet)){throw 'F32 short precondition did not pass'}
        }
    }
    $arguments=@('--capture',$fixture.capture.key,'--playback',$fixture.playback.key,'--low-grid','--pcm',$trial.pcm,'--seconds',"$($trial.seconds)")
    if($trial.unprimed){$arguments+='--unprimed'}
    $start=[DateTimeOffset]::UtcNow
    $process=Start-Process -FilePath $exe -ArgumentList $arguments -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput "$out/$($trial.name).stdout.log" -RedirectStandardError "$out/$($trial.name).stderr.log"
    $observations=[System.Collections.Generic.List[object]]::new()
    try {
        while(!$process.WaitForExit(1000)) {
            if(([DateTimeOffset]::UtcNow-$start).TotalSeconds -gt $trial.seconds+40){throw 'Trial exceeded independent watchdog'}
            $process.Refresh()
            if(!$process.HasExited){$observations.Add([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');cpu_ms=$process.TotalProcessorTime.TotalMilliseconds;working_set=$process.WorkingSet64})}
        }
        $process.WaitForExit()
        $results.Add([ordered]@{name=$trial.name;start_utc=$start.ToString('o');end_utc=[DateTimeOffset]::UtcNow.ToString('o');exit_code=$process.ExitCode;source=(git rev-parse HEAD);executable_sha256=(Get-FileHash $exe).Hash;arguments=$arguments;observations=@($observations)})
        $results | ConvertTo-Json -Depth 6 | Set-Content "$out/remaining-trials.json" -Encoding utf8
        Write-Output "$($trial.name) exit=$($process.ExitCode)"
    } finally {
        if(!$process.HasExited){$process.Kill();$process.WaitForExit()}
        $process.Dispose()
    }
}
