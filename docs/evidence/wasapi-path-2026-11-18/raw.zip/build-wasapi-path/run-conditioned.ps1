$ErrorActionPreference='Stop'
$root=(Get-Location).Path
$out=(Resolve-Path 'build-wasapi-path').Path
$exe=(Resolve-Path 'build-windows-validation/OFF-Release/hail_wasapi_loopback.exe').Path
$helper=(Resolve-Path 'build-windows-validation/OFF-Release/hail_wasapi_path.exe').Path
$fixture=Get-Content "$out/low-grid-manifest.json" -Raw | ConvertFrom-Json
foreach($file in 'low-grid-f32-conditioned-primed.log','low-grid-f32-conditioned-unprimed.log') {
    if(!(Select-String -Path "$out/$file" -Pattern '^PASS allocations=2 frees=2 ledger_bytes=0$' -Quiet)){throw 'Corrected short-case precondition failed'}
}
& $helper $fixture.capture.key $fixture.playback.key f32 --condition *> "$out/condition-before-sustained.log"
if($LASTEXITCODE -ne 0){throw 'Conditioning failed; no qualification started'}
$arguments=@('--capture',$fixture.capture.key,'--playback',$fixture.playback.key,'--low-grid','--pcm','f32','--seconds','600')
$start=[DateTimeOffset]::UtcNow
$process=Start-Process -FilePath $exe -ArgumentList $arguments -WorkingDirectory $root -WindowStyle Hidden -PassThru -RedirectStandardOutput "$out/low-grid-f32-conditioned-sustained.stdout.log" -RedirectStandardError "$out/low-grid-f32-conditioned-sustained.stderr.log"
$observations=[System.Collections.Generic.List[object]]::new()
try {
    while(!$process.WaitForExit(1000)) {
        if(([DateTimeOffset]::UtcNow-$start).TotalSeconds -gt 640){throw 'Independent watchdog expired'}
        $process.Refresh()
        if(!$process.HasExited){$observations.Add([ordered]@{utc=[DateTimeOffset]::UtcNow.ToString('o');cpu_ms=$process.TotalProcessorTime.TotalMilliseconds;working_set=$process.WorkingSet64})}
    }
    $process.WaitForExit()
    [ordered]@{name='low-grid-f32-conditioned-sustained';start_utc=$start.ToString('o');end_utc=[DateTimeOffset]::UtcNow.ToString('o');exit_code=$process.ExitCode;source=(git rev-parse HEAD);executable_sha256=(Get-FileHash $exe).Hash;conditioning_executable_sha256=(Get-FileHash $helper).Hash;arguments=$arguments;observations=@($observations)} |
        ConvertTo-Json -Depth 6 | Set-Content "$out/conditioned-sustained.json" -Encoding utf8
    Write-Output "low-grid-f32-conditioned-sustained exit=$($process.ExitCode)"
} finally {
    if(!$process.HasExited){$process.Kill();$process.WaitForExit()}
    $process.Dispose()
}
