"""Preserve raw diagnostics, provenance and a small machine-readable index."""
import datetime
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

root = Path.cwd()
build = root / 'build-wasapi-path'
out = root / 'docs/evidence/wasapi-path-2026-11-18'
out.mkdir(parents=True, exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def read_log(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')


files = [p for p in build.rglob('*') if p.is_file() and p.suffix in ('.log', '.json', '.ps1', '.py', '.txt')]
files += [p for p in (root/'build-wasapi-runner-test').rglob('*') if p.is_file() and p.suffix in ('.log', '.json', '.ps1', '.txt')]
for config in ('OFF-Debug', 'OFF-Release', 'ON-Debug', 'ON-Release'):
    files += list((root / 'build-windows-validation' / config).glob('*.log'))
artifacts = []
with zipfile.ZipFile(out / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):
        name = str(p.relative_to(root)).replace('\\', '/')
        z.write(p, name)
        artifacts.append(dict(path=name, bytes=p.stat().st_size, sha256=digest(p)))
    # The initial constant-run source is preserved independently of later changes.
    original = subprocess.check_output(['git', 'show', '31fb55e:tests/wasapi_path.c'])
    z.writestr('constant-diagnostic-source-31fb55e.c', original)

trials = []
for p in sorted(build.glob('*.log')):
    text = read_log(p)
    if not any(s in text for s in ('numerical_profile=', 'diagnostic=constant', 'FAIL line=')):
        continue
    entries = [line for line in text.splitlines() if line.startswith(('numerical_profile=', 'diagnostic=', 'level=', 'oracle_', 'sustained_', 'capture_frames=', 'restart_old_', 'flush_capture_', 'PASS ', 'FAIL ', 'COMPLETE '))]
    trials.append(dict(path=p.name, observations=entries))
record = dict(
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    numerical_profiles=dict(original='failed and retained separately', low='transparent-s16-grid-low-v1; exact zero tolerance; passing short/ASan cases but conditioned unprimed flush failed; sustained numerical minimum failed; S16 failed; no full pass'),
    provenance='Constant native runs use the audio-path source at 31fb55e; original executable hash not recorded. Corrected loopback trials use source at 4f54199. Final diagnostic bounds/observer builds are recorded by file hashes below.',
    sources=[dict(path=str(p.relative_to(root)).replace('\\', '/'), sha256=digest(p)) for p in (root/'tests/wasapi_loopback.c', root/'tests/wasapi_path.c')],
    executables=[dict(path=str(p.relative_to(root)).replace('\\', '/'), sha256=digest(p)) for p in (root/'build-windows-validation/OFF-Release/hail_wasapi_loopback.exe', root/'build-windows-validation/OFF-Release/hail_wasapi_path.exe', root/'build-windows-asan23/hail_wasapi_loopback.exe', root/'build-windows-asan23/hail_wasapi_path.exe')],
    trials=trials,
    raw_archive=dict(path='raw.zip', sha256=digest(out/'raw.zip'), entries=artifacts),
    limitations=['Unresolved fractional flush samples; no complete paired transition pass', 'First measured 600-second phase had zero transport loss but failed numerical minimum; second long attempt gated out', 'No S16 conversion oracle or original-profile pass', 'No new rates/channels qualified', 'No physical latency or audible-tail bound', 'No microphone PCM retained'],
)
(out/'summary.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive_bytes=(out/'raw.zip').stat().st_size, trials=len(trials), raw_entries=len(artifacts))))
