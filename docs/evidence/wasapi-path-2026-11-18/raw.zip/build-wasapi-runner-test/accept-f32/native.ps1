if($args -contains 's16'){exit 1}
if(($PSScriptRoot -like '*reject-unprimed*') -and ($args -contains '--unprimed')){exit 1}
Write-Output 'MOCK native process only; no devices opened'
exit 0
