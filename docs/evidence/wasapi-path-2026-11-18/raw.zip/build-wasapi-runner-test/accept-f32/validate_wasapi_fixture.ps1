param($Manifest,$Executable,$OutputDirectory)
[pscustomobject]@{sample_rate=48000;channels=2;profile='transparent-s16-grid-low-v1';capture=@{key='MOCK_CAPTURE'};playback=@{key='MOCK_RENDER'}}
