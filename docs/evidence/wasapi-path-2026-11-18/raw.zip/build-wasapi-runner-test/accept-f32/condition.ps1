Write-Output 'MOCK conditioning only; no devices opened'
exit 0
