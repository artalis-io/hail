set -eu
cd /tmp/hail-gate-e.6j9bHZ
mkdir -p debs sdk
cd debs
apt-get download libasound2-dev libpipewire-0.3-dev libspa-0.2-dev
for package in ./*.deb; do dpkg-deb -x "$package" ../sdk; done
cp /usr/lib/aarch64-linux-gnu/libasound.so.2.0.0 ../sdk/usr/lib/aarch64-linux-gnu/
cp /usr/lib/aarch64-linux-gnu/libpipewire-0.3.so.0.1005.0 ../sdk/usr/lib/aarch64-linux-gnu/
ln -sf libasound.so.2.0.0 ../sdk/usr/lib/aarch64-linux-gnu/libasound.so.2
ln -sf libpipewire-0.3.so.0.1005.0 ../sdk/usr/lib/aarch64-linux-gnu/libpipewire-0.3.so.0
cd ..
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
pkg-config --modversion alsa libpipewire-0.3
cmake -S . -B native -G Ninja -DCMAKE_BUILD_TYPE=Debug -DHA_BACKEND_ALSA=ON -DHA_BACKEND_PIPEWIRE=ON -DHA_BUILD_NATIVE_TESTS=OFF
cmake --build native --parallel 4
ctest --test-dir native --output-on-failure --timeout 60
python3 tools/check_contracts.py native/libhail.a
