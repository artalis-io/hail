import datetime,hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path.cwd(); run=root/'build-gate-e'; out=root/'docs/evidence/gate-e-2026-11-19'; out.mkdir(parents=True,exist_ok=True)
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
ci=load(run/'ci-c76b497.json'); fuzz=load(run/'fuzz-c76b497.json')
assert ci['conclusion']=='success' and len(ci['jobs'])==11 and all(j['conclusion']=='success' for j in ci['jobs'])
assert fuzz['conclusion']=='success'
final_ci=load(run/'ci-87e29d4.json'); final_fuzz=load(run/'fuzz-87e29d4.json')
assert final_ci['conclusion']=='success' and len(final_ci['jobs'])==11 and all(j['conclusion']=='success' for j in final_ci['jobs'])
assert final_fuzz['conclusion']=='success'
for config,tests in [('OFF-Debug',13),('OFF-Release',13),('ON-Debug',9),('ON-Release',9)]:
 folder=run/'windows'/config
 assert f'100% tests passed out of {tests}' in (folder/'ctest.log').read_text(encoding='utf-8-sig')
 assert '100% tests passed out of 3' in (folder/'consumer-ctest.log').read_text(encoding='utf-8-sig')
assert '100% tests passed out of 13' in (run/'asan-final-tests.log').read_text(encoding='utf-8-sig')
assert '100% tests passed out of 1' in (run/'asan-final-consumer-tests.log').read_text(encoding='utf-8-sig')
assert '100% tests passed, 0 tests failed out of 12' in (run/'linux-final-source-tests.log').read_text(encoding='utf-8-sig')
analyzer=load(run/'analyzer/analyzer-results.json'); assert len(analyzer)==10 and all(r['exit_code']==0 and not r['output'] for r in analyzer)
source_files=[p for directory in ['src','include','examples/dsp-consumer'] for p in (root/directory).rglob('*') if p.is_file()]
source_files.extend(root/f for f in ['CMakeLists.txt','tests/conformance.c','tests/alsa_null.c','tests/wasapi_buffers.c','tests/pipewire_buffers.c','.github/workflows/ci.yml','tools/check_windows_builds.ps1'])
provenance={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_files':{p.relative_to(root).as_posix():{'sha256':sha(p),'normalized_text_sha256':hashlib.sha256(p.read_text(encoding='utf-8').encode()).hexdigest()} for p in source_files},
 'windows_binaries':{str(p.relative_to(root)):sha(p) for p in [run/'windows/OFF-Release/hail.lib',run/'windows/ON-Release/hail.dll',run/'windows/OFF-Release/consumer/dsp/dsp_consumer.exe',root/'build-wasapi-sdk-asan/hail_conformance.exe',run/'asan-consumer/dsp_consumer.exe']},
 'linux':load(run/'linux-provenance.json'),
 'legacy_client':load(run/'legacy/result.json')}
(run/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(run.glob('*')):
  if p.is_file() and p.suffix in ['.log','.json','.sh','.py']: z.write(p,'run/'+p.name)
 for folder in ['analyzer','legacy']:
  for p in sorted((run/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.log','.json','.c','.h']: z.write(p,'run/'+p.relative_to(run).as_posix())
 for config in ['OFF-Debug','OFF-Release','ON-Debug','ON-Release']:
  for p in sorted((run/'windows'/config).glob('*.log')): z.write(p,f'windows/{config}/{p.name}')
  z.write(run/'windows'/config/'CMakeCache.txt',f'windows/{config}/CMakeCache.txt')
 for p in source_files: z.write(p,'source/'+p.relative_to(root).as_posix())
 z.write(root/'LICENSE','source/LICENSE')
with zipfile.ZipFile(out/'raw.zip') as z: assert z.testzip() is None
summary={'date':'2026-11-19','gate_e':'PARTIAL','source_commit':provenance['source_commit'],
 'independent_consumer':{'installed_public_headers_only':True,'production_sources_or_private_headers':False,'nominal_modeled_capture_seconds_longest':700,'physical_audio':False},
 'checks':{'windows_static_debug_release':'13/13 each','windows_shared_debug_release':'9/9 each','windows_installed_consumers':'3/3 each of four configurations','windows_matching_llvm23_asan':'13/13 + independent consumer 1/1','linux_arm64_gcc_asan_ubsan':'7/7 portable + independent consumer 1/1; 12/12 native/portable including ALSA null 2/4/32 channels','clang_analyzer':'10 successful invocations; no diagnostics','legacy_header_client':'400-byte original stream_info prefix; tail canaries intact','ci_implementation':{'revision':ci['headSha'],'jobs':11,'result':'success','url':ci['url']},'fuzz_implementation':{'revision':fuzz['headSha'],'result':'success','url':fuzz['url']},'ci_final_regressions':{'revision':final_ci['headSha'],'jobs':11,'result':'success','url':final_ci['url']},'fuzz_final_regressions':{'revision':final_fuzz['headSha'],'result':'success','url':final_fuzz['url']}},
 'retained_failures':{'windows_initial_asan':'concurrency process stalled with Visual Studio-path ASan DLL; terminated; matching LLVM23 runtime profile passes','linux_arm64_tsan':'7/7 runtime initialization failures: unexpected memory mapping; no executed race coverage','remote_shell_initial':'CRLF shell-input setup failure before build; corrected byte transport'},
 'physical_status':'No fresh microphone/cable/acoustic measurement; prior WASAPI paired failures retained; no latency, alignment, audible-tail or deadline qualification claimed',
 'abi':'Provisional; optional tail compatible in tested old-header case; no freeze',
 'artifacts':{'raw.zip':{'sha256':sha(out/'raw.zip'),'bytes':(out/'raw.zip').stat().st_size}}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS evidence assertions and ZIP integrity; archive bytes', (out/'raw.zip').stat().st_size)
