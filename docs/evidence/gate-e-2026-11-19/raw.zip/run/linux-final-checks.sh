set -eu
cd /tmp/hail-gate-e.6j9bHZ
cmake --build asan --parallel 4
ctest --test-dir asan --output-on-failure --timeout 60
cmake --build asan-consumer --parallel 4
ctest --test-dir asan-consumer --output-on-failure
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
cmake --build native-asan --parallel 4
ctest --test-dir native-asan -E pipewire_loopback --output-on-failure --timeout 60
