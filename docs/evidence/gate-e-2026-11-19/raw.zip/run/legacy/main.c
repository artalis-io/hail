#include <hail.h>
#include <assert.h>
#include <stdio.h>
int main(void) {
 ha_context_config cc=HA_INIT(ha_context_config); ha_context *c=0; ha_stream *s=0;
 ha_stream_config cfg=HA_INIT(ha_stream_config); ha_device_selector d=HA_INIT(ha_device_selector);
 ha_format f=HA_FORMAT_INIT(48000,1,HA_PCM_F32); unsigned n=0;
 struct record { ha_stream_info info; uint64_t canary[2]; } record={0};
 record.info=(ha_stream_info)HA_INIT(ha_stream_info); record.canary[0]=UINT64_C(0x123456789abcdef0); record.canary[1]=UINT64_MAX;
 cc.backend=HA_BACKEND_VIRTUAL; cfg.directions=HA_CAPTURE; cfg.capture_device=d; cfg.capture_format=f;
 assert(ha_context_create(&cc,&c)==HA_OK); assert(ha_stream_open(c,&cfg,&s)==HA_OK);
 assert(ha_stream_get_info(s,&record.info)==HA_OK); assert(record.info.capture_format.sample_rate==48000);
 assert(record.canary[0]==UINT64_C(0x123456789abcdef0) && record.canary[1]==UINT64_MAX);
 assert(ha_stream_close_begin(s)==HA_PENDING); assert(ha_context_poll(c,0,0,&n)==HA_OK);
 assert(ha_stream_close_finish(&s)==HA_OK); assert(ha_context_destroy(&c)==HA_OK);
 printf("PASS old-header client prefix_bytes=%zu linked against new Hail; tail canaries intact\n",sizeof(ha_stream_info)); return 0;
}
