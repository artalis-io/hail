set -eu
cd /tmp/hail-gate-e.6j9bHZ
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
cmake -S . -B native-asan -G Ninja -DCMAKE_BUILD_TYPE=Debug -DHA_BACKEND_ALSA=ON -DHA_BACKEND_PIPEWIRE=ON -DHA_BUILD_NATIVE_TESTS=ON -DHA_SANITIZER=address
cmake --build native-asan --parallel 4
ctest --test-dir native-asan -E pipewire_loopback --output-on-failure --timeout 60
