import ctypes
import json
import subprocess
from pathlib import Path

root=Path.cwd()
output=root/'build-gate-e/analyzer'
shell=ctypes.WinDLL('shell32')
shell.CommandLineToArgvW.argtypes=(ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int))
shell.CommandLineToArgvW.restype=ctypes.POINTER(ctypes.c_wchar_p)
kernel=ctypes.WinDLL('kernel32')
kernel.LocalFree.argtypes=(ctypes.c_void_p,)

def split(command):
    count=ctypes.c_int()
    argv=shell.CommandLineToArgvW(command,ctypes.byref(count))
    if not argv: raise ctypes.WinError()
    try: return [argv[i] for i in range(count.value)]
    finally: kernel.LocalFree(argv)

database=json.loads((root/'build-gate-e/windows/OFF-Release/compile_commands.json').read_text())
targets=('src/core.c','src/queue.c','src/native.c','src/virtual.c','src/hosted.c','src/backend_wasapi.c','tests/wasapi_loopback.c','tools/probes/wasapi_native_repro.c')
results=[]
for entry in database:
    file=Path(entry['file'])
    relative=file.relative_to(root).as_posix()
    if relative not in targets: continue
    for diagnostic in ((False,True) if relative in ('src/backend_wasapi.c','tests/wasapi_loopback.c') else (False,)):
        args=split(entry['command'])
        filtered=[a for a in args[1:] if a!='-c' and not a.startswith(('/Fo','/Fd','-DHA_WASAPI_DIAGNOSTICS='))]
        additions=['--analyze','/clang:-Xanalyzer','/clang:-analyzer-output=text',f'-DHA_WASAPI_DIAGNOSTICS={int(diagnostic)}','-I'+str(root/'src')]
        command=[args[0],*additions,*filtered]
        result=subprocess.run(command,cwd=entry['directory'],capture_output=True,text=True)
        name=relative.replace('/','_')+('.sdk' if diagnostic else '')
        (output/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
        results.append(dict(file=relative,sdk_diagnostics=diagnostic,exit_code=result.returncode,output=(result.stdout+result.stderr).strip(),command=command))
(output/'analyzer-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(file=r['file'],sdk=r['sdk_diagnostics'],exit_code=r['exit_code'],output=r['output']) for r in results],indent=2))
if any(r['exit_code'] for r in results): raise SystemExit(1)
