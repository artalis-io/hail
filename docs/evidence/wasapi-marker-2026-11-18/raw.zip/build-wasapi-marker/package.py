import csv
import hashlib
import json
import re
import zipfile
from pathlib import Path

root = Path.cwd()
build = root / 'build-wasapi-marker'
out = root / 'docs/evidence/wasapi-marker-2026-11-18'
out.mkdir(parents=True, exist_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest().upper()


def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')


def fields(line):
    return dict(re.findall(r'(\w+)=([^\s]+)', line))


cases = []
campaigns = {}
for campaign in ('matrix', 'sdk-matrix'):
    folder = build / campaign
    campaigns[campaign] = json.loads(read(folder/'summary.json'))
    results = json.loads(read(folder/'results.json'))
    for result in results:
        if result['name'].endswith('.condition'):
            continue
        lines = read(folder/(result['name']+'.stdout.log')).splitlines()
        stages, sdk = {}, {}
        examples = {}
        setup, pairs = {}, {}
        for line in lines:
            f = fields(line)
            if line.startswith('marker_stage='):
                stages[f['marker_stage']+':'+f['phase']] = f
            elif line.startswith('marker_example '):
                examples[(f['stage'], f['phase'], f['position'], f['host_ns'])] = f
            elif line.startswith('sdk_boundary='):
                sdk[f['sdk_boundary']] = f
            elif line.startswith('flush_setup '):
                setup = f
            elif line.startswith('marker_trace '):
                pairs = f
        sdk_examples = [fields(x) for x in lines if x.startswith('sdk_example leg=0 ')]
        matching = []
        for sample in sdk_examples:
            for example in examples.values():
                if example['stage'] != 'hail_capture' or example['position'] != sample['position']:
                    continue
                if abs(int(example['host_ns'])-int(sample['host_ns'])) <= 100 and all(float(example[k]) == float(sample[k]) for k in ('left_s16', 'right_s16')):
                    matching.append(dict(sdk=sample, hail=example))
                    break
        cases.append(dict(campaign=campaign, name=result['name'], exit_code=result['exit_code'],
                          stdout_sha256=result['stdout_sha256'], setup=setup, stages=stages, pairing=pairs,
                          sdk_boundaries=sdk, matched_fractional_examples=matching))

files = [p for p in build.rglob('*') if p.is_file() and p.suffix in ('.log', '.json', '.jsonl', '.ps1', '.py', '.txt')]
for config in ('OFF-Debug', 'OFF-Release', 'ON-Debug', 'ON-Release'):
    files.extend((root/'build-windows-validation'/config).glob('*.log'))
for folder in ('build-wasapi-sdk', 'build-wasapi-sdk-asan'):
    files.extend(p for p in (root/folder/'CMakeCache.txt', root/folder/'CMakeFiles/CMakeConfigureLog.yaml', root/folder/'Testing/Temporary/LastTest.log') if p.exists())
entries = []
with zipfile.ZipFile(out/'raw.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):
        name = p.relative_to(root).as_posix()
        data = p.read_bytes()
        z.writestr(name, data)
        entries.append(dict(path=name, bytes=len(data), sha256=digest(data)))

summary = dict(campaigns=campaigns, cases=cases,
               raw_archive=dict(path='raw.zip', sha256=digest((out/'raw.zip').read_bytes()), entries=entries),
               defaults_preserved=read(build/'defaults-before.jsonl') == read(build/'defaults-after.jsonl'),
               shure_settings_preserved=read(build/'shure-before.json') == read(build/'shure-after.json'),
               interpretation='SDK capture lease already contains matching fractional values; render lease is exact on the S16 grid. Specific Windows/driver/cable component not isolated. No complete qualification pass.',
               native_asan_log='build-wasapi-marker/checks/sdk-asan-native.log',
               physical_latency='not measured')
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
with (out/'matrix.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(('campaign','case','exit_code','flush_hail_fractional','flush_reference_fractional','flush_native_fractional','flush_loopback_fractional','sdk_capture_fractional','sdk_render_fractional','matching_sdk_examples','observed_delay_ns'))
    for c in cases:
        stages=[c['stages'].get(s+':2',{}) for s in ('hail_capture','hail_reference','native_cable_f32','native_render_loopback_f32')]
        w.writerow((c['campaign'],c['name'],c['exit_code'],*[s.get('fractional','') if int(s.get('frames',0)) else '' for s in stages],
                    *[c['sdk_boundaries'].get(s,{}).get('fractional','') for s in ('capture_buffer_before_hail','render_buffer_before_release')],len(c['matched_fractional_examples']),c['setup'].get('observed_delay_ns','')))
print(json.dumps(dict(cases=len(cases),failed=[c['campaign']+'/'+c['name'] for c in cases if c['exit_code']],
                      matching_examples=sum(len(c['matched_fractional_examples']) for c in cases),
                      independent_pairs=sum(int(c['pairing'].get('paired_frames',0)) for c in cases if c['campaign']=='matrix'),
                      independent_mismatches=sum(int(c['pairing'].get('paired_mismatches',0)) for c in cases if c['campaign']=='matrix'),
                      archive_bytes=(out/'raw.zip').stat().st_size,
                      defaults_preserved=summary['defaults_preserved'],shure_settings_preserved=summary['shure_settings_preserved'])))
