Standalone Windows WASAPI/VB-CABLE marker reproduction

Observed result: 16/16 exact cases passed; fractional ramp NOT reproduced.
This reduced scheduling/priming model does not qualify Hail paired transitions.
See wasapi-native-only-results.md and the predeclared plan for limits.

Build from an x64 Visual Studio developer shell with clang-cl and Windows SDK:
clang-cl /nologo /W4 /WX /std:c11 wasapi_native_repro.c /link ole32.lib uuid.lib
Device-free oracle:
wasapi_native_repro.exe --self-test
Authorized reserved synthetic 48 kHz stereo VB-CABLE pair only:
wasapi_native_repro.exe CAPTURE_ENDPOINT_ID RENDER_ENDPOINT_ID UNPRIMED DELAY_MS ACK_DELAY_MS
UNPRIMED=0/1; fixed matrix DELAY_MS=0/3/7/11 and ACK_DELAY_MS=0/16.
Endpoints must be explicit; no defaults are selected or settings changed.
Each process self-conditions silence and releases resources before reporting.
Exit 0=exact pass; 1=numerical rejection; 2=setup/SDK/check failure.
Place a 40-second independent process watchdog around each invocation.
No Hail library, driver binary or bulk PCM is included.
