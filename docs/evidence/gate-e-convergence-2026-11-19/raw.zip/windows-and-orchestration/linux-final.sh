set -eu
cd /tmp/hail-gate-e-final.lTzsbV
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
git rev-parse HEAD
uname -a
gcc --version
pipewire --version
for mode in static shared asan; do
 shared=OFF; san=
 if [ "$mode" = shared ]; then shared=ON; fi
 if [ "$mode" = asan ]; then san=address; fi
 cmake -S . -B "$mode" -G Ninja -DCMAKE_BUILD_TYPE=Debug -DHA_BUILD_SHARED="$shared" -DHA_SANITIZER="$san" -DHA_BACKEND_ALSA=ON -DHA_BACKEND_PIPEWIRE=ON -DHA_BUILD_NATIVE_TESTS=ON
 cmake --build "$mode" --parallel 4
 ctest --test-dir "$mode" --output-on-failure --timeout 60
 cmake --install "$mode" --prefix "$PWD/$mode-installed"
 cmake -S tests/consumer -B "$mode-consumer" -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_PREFIX_PATH="$PWD/$mode-installed" -DHA_CONSUMER_DSP=ON
 cmake --build "$mode-consumer" --parallel 4
 ctest --test-dir "$mode-consumer" --output-on-failure --timeout 180
 if [ "$shared" = ON ]; then python3 tools/check_contracts.py "$mode/libhail.so" --shared; else python3 tools/check_contracts.py "$mode/libhail.a"; fi
done
