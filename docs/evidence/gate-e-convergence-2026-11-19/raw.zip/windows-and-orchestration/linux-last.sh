set -u
cd /tmp/hail-gate-e-final.lTzsbV
git pull --ff-only
export LD_LIBRARY_PATH="$PWD/compiler/usr/lib/aarch64-linux-gnu"
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
for mode in static shared asan clang-native; do
 cmake --build "$mode" --parallel 4 || exit 1
 ctest --test-dir "$mode" --output-on-failure --timeout 60 || exit 1
done
cmake -S . -B tsan-gcc -G Ninja -DCMAKE_BUILD_TYPE=Debug -DHA_SANITIZER=thread -DHA_BACKEND_ALSA=OFF -DHA_BACKEND_PIPEWIRE=OFF || exit 1
cmake --build tsan-gcc --parallel 4 || exit 1
ctest --test-dir tsan-gcc --output-on-failure --timeout 30
echo gcc_tsan_exit=$?
cmake -S . -B tsan-clang -G Ninja -DCMAKE_C_COMPILER="$PWD/compiler/usr/bin/clang-18" -DCMAKE_CXX_COMPILER="$PWD/compiler/usr/bin/clang++-18" -DCMAKE_BUILD_TYPE=Debug -DHA_SANITIZER=thread -DHA_BACKEND_ALSA=OFF -DHA_BACKEND_PIPEWIRE=OFF || exit 1
cmake --build tsan-clang --parallel 4 || exit 1
ctest --test-dir tsan-clang --output-on-failure --timeout 30
echo clang_tsan_exit=$?
