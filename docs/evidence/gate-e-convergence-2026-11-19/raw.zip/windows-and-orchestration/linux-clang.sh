set -eu
cd /tmp/hail-gate-e-final.lTzsbV
export LD_LIBRARY_PATH="$PWD/compiler/usr/lib/aarch64-linux-gnu"
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
cmake -S . -B fuzz-build -G Ninja -DCMAKE_C_COMPILER="$PWD/compiler/usr/bin/clang-18" -DCMAKE_BUILD_TYPE=RelWithDebInfo -DHA_BUILD_FUZZER=ON -DHA_BUILD_TESTS=OFF -DHA_BUILD_EXAMPLES=OFF -DHA_SANITIZER=address -DHA_BACKEND_COREAUDIO=OFF -DHA_BACKEND_WASAPI=OFF -DHA_BACKEND_ALSA=OFF -DHA_BACKEND_PIPEWIRE=OFF
cmake --build fuzz-build --parallel 4
python3 tools/run_fuzz.py --build-dir fuzz-build --output-dir fuzz-build/results --runs 30000
cmake -S . -B clang-native -G Ninja -DCMAKE_C_COMPILER="$PWD/compiler/usr/bin/clang-18" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DHA_BACKEND_ALSA=ON -DHA_BACKEND_PIPEWIRE=ON -DHA_BUILD_NATIVE_TESTS=ON
cmake --build clang-native --parallel 4
ctest --test-dir clang-native --output-on-failure --timeout 60
python3 - <<'PY'
import json,shlex,subprocess
from pathlib import Path
entries=json.loads(Path('clang-native/compile_commands.json').read_text())
results=[]
for e in entries:
    name=Path(e['file']).name
    if name not in ('core.c','queue.c','native.c','virtual.c','backend_pipewire.c','backend_alsa.c'):
        continue
    args=shlex.split(e['command']); filtered=[]; i=1
    while i<len(args):
        if args[i]=='-o': i+=2; continue
        if args[i]!='-c': filtered.append(args[i])
        i+=1
    r=subprocess.run([args[0],'--analyze','-Xanalyzer','-analyzer-output=text',*filtered],cwd=e['directory'],capture_output=True,text=True)
    results.append(dict(file=name,exit_code=r.returncode,diagnostics=r.stdout+r.stderr))
Path('clang-native/analyzer.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
if any(r['exit_code'] or r['diagnostics'] for r in results): raise SystemExit(1)
PY
