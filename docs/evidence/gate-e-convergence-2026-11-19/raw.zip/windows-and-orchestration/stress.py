import subprocess,sys,time,json,statistics
from pathlib import Path
workers=[]; durations=[]
try:
    for _ in range(2):
        workers.append(subprocess.Popen([sys.executable,'-c','import hashlib\nb=b"x"*1048576\nwhile True: hashlib.sha256(b).digest()'],creationflags=subprocess.CREATE_NO_WINDOW))
    for _ in range(30):
        start=time.perf_counter_ns()
        r=subprocess.run(['build-gate-e/convergence/windows-final/OFF-Release/hail_concurrency.exe'],capture_output=True,timeout=15)
        if r.returncode: raise RuntimeError(r.stderr.decode(errors='replace'))
        durations.append(time.perf_counter_ns()-start)
finally:
    for p in workers: p.terminate()
    for p in workers: p.wait(timeout=10)
Path('build-gate-e/convergence/contention.json').write_text(json.dumps(dict(runs=len(durations),all_passed=len(durations)==30,workers=2,load='SHA256 of fixed 1MiB buffers',scope='whole public concurrency test wall time; NOT device callback duration or deadline qualification',median_ns=statistics.median(durations),maximum_ns=max(durations)),indent=2)+'\n')
