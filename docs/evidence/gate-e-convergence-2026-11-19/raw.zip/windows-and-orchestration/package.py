from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile
root=Path.cwd(); folder=root/'build-gate-e/convergence'
out=root/'docs/evidence/gate-e-convergence-2026-11-19'; out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tracked=subprocess.check_output(['git','ls-files'],text=True).splitlines()
sources=[p for p in tracked if p.startswith(('src/','include/','fuzz/','tools/','tests/','cmake/','.github/','examples/dsp-consumer/')) or p=='CMakeLists.txt']
index={}
with zipfile.ZipFile(out/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    def add(name,data):
        z.writestr(name,data); index[name]=dict(bytes=len(data),sha256=sha(data))
    for p in sources: add('source/'+p,(root/p).read_bytes())
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or any(x in p.parts for x in ('CMakeFiles','__pycache__','installed')): continue
        if p.suffix.lower() not in ('.log','.json','.ps1','.py','.sh','.c','.stdout','.stderr','.txt') and p.name!='CMakeCache.txt': continue
        add('windows-and-orchestration/'+p.relative_to(folder).as_posix(),p.read_bytes())
    with tarfile.open(folder/'linux-evidence.tar.gz','r:gz') as t:
        for m in t:
            if m.isfile(): add('linux/'+m.name,t.extractfile(m).read())
    # The Windows analyzer was rerun with its original output directory.
    for p in sorted((root/'build-gate-e/analyzer').glob('*')):
        if p.is_file(): add('windows-clang-analyzer/'+p.name,p.read_bytes())
    add('index.json',(json.dumps(index,indent=2)+'\n').encode())
summary=dict(source_revision=revision,base_revision='a5b247b',gate='PARTIAL',public_api_changes_this_followup=False,
 source_sha256={p:sha((root/p).read_bytes()) for p in sources},
 findings=dict(E1='SPA ring offsets/wrapped capture corrected',E2='neutral capture flags zero PCM and report silence',
 E3='recycled output flags cleared',E4='Windows PowerShell redirected process handles retained'),
 verification=dict(windows_static_debug_release='16/16 each; installed 3/3 each',windows_shared_debug_release='12/12 each; installed 3/3 each',
 windows_asan='16/16; independent installed DSP 1/1; matching LLVM 23 runtime',
 linux_native_gcc_static='14/14; installed 3/3',linux_native_gcc_shared='9/9; installed 3/3',
 linux_native_gcc_asan_ubsan='14/14; installed 3/3',linux_native_clang='14/14',
 linux_clang_tsan='portable 8/8, native 14/14, installed consumers 3/3',
 linux_gcc_tsan='runtime initialization failure in 7/8 tests; Python test passes; not a Hail race finding',
 fuzz='four Clang ASan/UBSan libFuzzer campaigns, 30000 runs each, all pass',
 analysis='Windows 10 invocations and Linux 8 invocations; no diagnostics',
 freestanding='conformance and 27-export boundary checks pass; minimum no-virtual 22-export boundary checks pass',
 contention='30/30 public threaded-role runs with two CPU load workers; not callback deadline evidence',
 offline_tools='8 synthetic tests pass on Windows and Linux',
 macos='device-free format regression added; no local execution; CI pending'),
 wasapi=dict(scope='signed VB-CABLE 3.5.2.0, 48k stereo F32 software loopback; not physical',
 initial_campaign='aborted before qualification cases due to null redirected process exit code; conditioning completed',
 final_campaign='two predeclared historical configurations, each once, both pass; oracle unchanged',
 flush_ack_ns=[23748700,26147100],old_marker_capture_read_after_cancel_ns=[103817400,107358100],
 native_numerical_blocker='historical intermittent F32 failures remain unresolved; S16 alteration still observed during conditioning',
 defaults_and_shure_gain_mute='before/after readbacks identical'),
 remaining=['calibrated physical capture/playback/round-trip latency','physical reference alignment and clock drift',
 'callback deadline/jitter distributions on supported physical profiles','presentation/electrical/acoustic cancellation tails',
 'physical lifecycle/recovery matrix across platforms','queued macOS and cross-platform CI','provisional ABI risks'],
 retained_failures=['pre-fix PipeWire callback regressions','initial new-test BUSY/PENDING assumption',
 'Windows PowerShell redirected exit-code failure and CTest module-path failure',
 'GCC ARM64 TSan initialization failures','ASan archive rejected by strict ordinary symbol checker',
 'initial orchestration configure/quoting errors'],
 ci=json.loads((folder/'ci-final.json').read_text(encoding='utf-8-sig')),
 raw=dict(path='raw.zip',bytes=(out/'raw.zip').stat().st_size,sha256=sha((out/'raw.zip').read_bytes()),entries=len(index)))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(revision=revision,archive_bytes=summary['raw']['bytes'],entries=len(index)),indent=2))
