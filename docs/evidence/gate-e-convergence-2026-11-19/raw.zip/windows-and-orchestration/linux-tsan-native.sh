set -eu
cd /tmp/hail-gate-e-final.lTzsbV
export LD_LIBRARY_PATH="$PWD/compiler/usr/lib/aarch64-linux-gnu"
export PKG_CONFIG_SYSROOT_DIR=/tmp/hail-gate-e.6j9bHZ/sdk
export PKG_CONFIG_LIBDIR=/tmp/hail-gate-e.6j9bHZ/sdk/usr/lib/aarch64-linux-gnu/pkgconfig
cmake -S . -B tsan-clang-native -G Ninja -DCMAKE_C_COMPILER="$PWD/compiler/usr/bin/clang-18" -DCMAKE_CXX_COMPILER="$PWD/compiler/usr/bin/clang++-18" -DCMAKE_BUILD_TYPE=Debug -DHA_SANITIZER=thread -DHA_BACKEND_ALSA=ON -DHA_BACKEND_PIPEWIRE=ON -DHA_BUILD_NATIVE_TESTS=ON
cmake --build tsan-clang-native --parallel 4
ctest --test-dir tsan-clang-native --output-on-failure --timeout 60
cmake --install tsan-clang-native --prefix "$PWD/tsan-installed"
cmake -S tests/consumer -B tsan-consumer -G Ninja -DCMAKE_C_COMPILER="$PWD/compiler/usr/bin/clang-18" -DCMAKE_CXX_COMPILER="$PWD/compiler/usr/bin/clang++-18" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_PREFIX_PATH="$PWD/tsan-installed" -DHA_CONSUMER_DSP=ON
cmake --build tsan-consumer --parallel 4
ctest --test-dir tsan-consumer --output-on-failure --timeout 180
