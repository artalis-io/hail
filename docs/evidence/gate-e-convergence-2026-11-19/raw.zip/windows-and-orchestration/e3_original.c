#define _POSIX_C_SOURCE 200809L
#include <pipewire/pipewire.h>
#include <hail.h>
#include <stdio.h>
#include <errno.h>
static struct pw_buffer *lease;
static struct pw_buffer *take(struct pw_stream *p) { (void)p; return lease; }
static int give(struct pw_stream *p,struct pw_buffer *b) { (void)p; (void)b; return 0; }
static int no_time(struct pw_stream *p,struct pw_time *t,size_t n) { (void)p;(void)t;(void)n;return -ENOTSUP; }
#define pw_stream_dequeue_buffer take
#define pw_stream_queue_buffer give
#define pw_stream_get_time_n no_time
#define hail_pipewire_backend hail_test_e3_backend
#ifdef ORIGINAL
#include "a5_backend_pipewire.c"
#else
#include "backend_pipewire.c"
#endif
#undef hail_pipewire_backend
int main(void)
{
    ha_context_config cc=HA_INIT(ha_context_config); ha_stream_config sc=HA_INIT(ha_stream_config);
    ha_device_selector selector=HA_INIT(ha_device_selector); ha_format f=HA_FORMAT_INIT(48000,1,HA_PCM_S16);
    ha_context *c; ha_stream *s; uint32_t n; pw_hail_leg leg={0};
    const int16_t signal[]={101,202,303,404}; int16_t output[4]={0};
    struct spa_chunk chunk={0}; struct spa_data data={0}; struct spa_buffer buffer={0}; struct pw_buffer pw={0};
    cc.backend=HA_BACKEND_VIRTUAL;
    if(ha_context_create(&cc,&c)!=HA_OK) return 2;
    sc.directions=HA_PLAYBACK;sc.playback_device=selector;sc.playback_format=f;sc.quantum_frames=4;sc.reference_slots=2;
    if(ha_stream_open(c,&sc,&s)!=HA_OK || ha_stream_start(s)!=HA_PENDING || ha_context_poll(c,NULL,0,&n)!=HA_OK) return 2;
    s->concurrent=1;hail_rt_open(s,1);leg.owner=s;leg.leg=1;atomic_init(&leg.prepared,1);atomic_init(&leg.callbacks,0);
    chunk.flags=SPA_CHUNK_FLAG_EMPTY;data.data=output;data.maxsize=sizeof(output);data.chunk=&chunk;
    buffer.n_datas=1;buffer.datas=&data;pw.buffer=&buffer;lease=&pw;
    if(ha_stream_write(s,signal,4,1,&n)!=HA_OK || n!=4) return 2;
    stream_process(&leg);
    printf("nonzero_payload_exact=%d recycled_empty_flag=%u\n",!memcmp(signal,output,sizeof(signal)),(unsigned)(chunk.flags&SPA_CHUNK_FLAG_EMPTY));
    return memcmp(signal,output,sizeof(signal)) || (chunk.flags&SPA_CHUNK_FLAG_EMPTY) ? 1 : 0;
}
