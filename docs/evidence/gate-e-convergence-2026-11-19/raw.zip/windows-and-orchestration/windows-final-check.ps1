$ErrorActionPreference='Stop'
foreach($shared in 'OFF','ON') { foreach($config in 'Debug','Release') {
$b="build-gate-e/convergence/windows-final/$shared-$config"
cmake --build $b --parallel 4 *> "$b/build-final.log"; if($LASTEXITCODE){throw 'build failed'}
ctest --test-dir $b --output-on-failure *> "$b/ctest-final.log"; if($LASTEXITCODE){throw 'test failed'}
cmake --build "$b/consumer" --parallel 4 *> "$b/consumer-build-final.log"; if($LASTEXITCODE){throw 'consumer build failed'}
$oldPath=$env:PATH; try {$env:PATH="$((Resolve-Path "$b/installed/bin" -ErrorAction SilentlyContinue).Path);$oldPath"; ctest --test-dir "$b/consumer" --output-on-failure *> "$b/consumer-ctest-final.log"; if($LASTEXITCODE){throw 'consumer failed'}} finally {$env:PATH=$oldPath}
Write-Output "PASS $shared-$config"
}}
