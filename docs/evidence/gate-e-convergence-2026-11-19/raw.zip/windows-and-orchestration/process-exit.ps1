foreach($cache in $false,$true) {
$p=Start-Process -FilePath "$env:SystemRoot/System32/cmd.exe" -ArgumentList '/c exit 7' -WindowStyle Hidden -PassThru -RedirectStandardOutput "build-gate-e/convergence/exit-$cache.stdout" -RedirectStandardError "build-gate-e/convergence/exit-$cache.stderr"
if($cache){$null=$p.Handle}; $p.WaitForExit(); "cache=$cache exit=$($p.ExitCode)"; $p.Dispose()
}
