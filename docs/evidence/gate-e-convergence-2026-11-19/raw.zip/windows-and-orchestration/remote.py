from pathlib import Path
import subprocess, shlex, sys
remote='/tmp/hail-gate-e.6j9bHZ'
for name in sys.argv[2:]:
    code=f"from pathlib import Path; import sys; p=Path({remote+'/'+name!r}); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(sys.stdin.buffer.read())"
    subprocess.run(['ssh','spark-7468','python3 -c '+shlex.quote(code)],input=Path(name).read_bytes(),check=True)
script=sys.argv[1].replace('@ROOT@',remote)
r=subprocess.run(['ssh','spark-7468','sh'],input=script.encode(),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
sys.stdout.buffer.write(r.stdout)
sys.exit(r.returncode)
